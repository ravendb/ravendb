using Rhino.DivanDB.Linq;
using System.Linq;
using System;
public class ordersByCountry : AbstractViewGenerator
{
	public ordersByCountry()
	{
		this.ViewText = "\r\n                from doc in docs         \r\n                where doc.ObjectType == \"Order\"       \r\n                select new { doc.ShipCountry };\r\n            ";
		this.IndexDefinition = (System.Collections.Generic.IEnumerable<Rhino.DivanDB.Json.JsonDynamicObject> docs) => from doc in docs
			where doc["ObjectType"] == "Order"
			select new { ShipCountry = doc["ShipCountry"], _id = doc["_id"].Unwrap() };
	}
}

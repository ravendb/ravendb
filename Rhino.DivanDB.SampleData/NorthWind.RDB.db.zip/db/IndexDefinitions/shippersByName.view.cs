using Rhino.DivanDB.Linq;
using System.Linq;
using System;
public class shippersByName : AbstractViewGenerator
{
	public shippersByName()
	{
		this.ViewText = "\r\n                from doc in docs         \r\n                where doc.ObjectType == \"Shipper\"       \r\n                select new { doc.CompanyName };\r\n            ";
		this.IndexDefinition = (System.Collections.Generic.IEnumerable<Rhino.DivanDB.Json.JsonDynamicObject> docs) => from doc in docs
			where doc["ObjectType"] == "Shipper"
			select new { CompanyName = doc["CompanyName"], _id = doc["_id"].Unwrap() };
	}
}

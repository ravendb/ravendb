using Rhino.DivanDB.Linq;
using System.Linq;
using System;
public class customersByCompanyName : AbstractViewGenerator
{
	public customersByCompanyName()
	{
		this.ViewText = "from doc in docs         \nwhere doc.ObjectType == \"Customer\"       \nselect new { doc.CompanyName };";
		this.IndexDefinition = (System.Collections.Generic.IEnumerable<Rhino.DivanDB.Json.JsonDynamicObject> docs) => from doc in docs
			where doc["ObjectType"] == "Customer"
			select new { CompanyName = doc["CompanyName"], _id = doc["_id"].Unwrap() };
	}
}

using Rhino.DivanDB.Linq;
using System.Linq;
using System;
public class employeesByLastName : AbstractViewGenerator
{
	public employeesByLastName()
	{
		this.ViewText = "\r\n                from doc in docs         \r\n                where doc.ObjectType == \"Employee\"       \r\n                select new { doc.LastName };\r\n            ";
		this.IndexDefinition = (System.Collections.Generic.IEnumerable<Rhino.DivanDB.Json.JsonDynamicObject> docs) => from doc in docs
			where doc["ObjectType"] == "Employee"
			select new { LastName = doc["LastName"], _id = doc["_id"].Unwrap() };
	}
}

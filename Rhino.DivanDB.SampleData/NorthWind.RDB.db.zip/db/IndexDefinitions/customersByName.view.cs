using Rhino.DivanDB.Linq;
using System.Linq;
using System;
public class customersByName : AbstractViewGenerator
{
	public customersByName()
	{
		this.ViewText = "\r\n                from doc in docs         \r\n                where doc.ObjectType == \"Customer\"       \r\n                select new { doc.ContactName };\r\n            ";
		this.IndexDefinition = (System.Collections.Generic.IEnumerable<Rhino.DivanDB.Json.JsonDynamicObject> docs) => from doc in docs
			where doc["ObjectType"] == "Customer"
			select new { ContactName = doc["ContactName"], _id = doc["_id"].Unwrap() };
	}
}

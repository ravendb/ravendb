using Rhino.DivanDB.Linq;
using System.Linq;
using System;
public class productsByName : AbstractViewGenerator
{
	public productsByName()
	{
		this.ViewText = "\r\n                from doc in docs         \r\n                where doc.ObjectType == \"Product\"       \r\n                select new { doc.ProductName };\r\n            ";
		this.IndexDefinition = (System.Collections.Generic.IEnumerable<Rhino.DivanDB.Json.JsonDynamicObject> docs) => from doc in docs
			where doc["ObjectType"] == "Product"
			select new { ProductName = doc["ProductName"], _id = doc["_id"].Unwrap() };
	}
}

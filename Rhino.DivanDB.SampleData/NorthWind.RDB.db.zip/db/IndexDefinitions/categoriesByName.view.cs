using Rhino.DivanDB.Linq;
using System.Linq;
using System;
public class categoriesByName : AbstractViewGenerator
{
	public categoriesByName()
	{
		this.ViewText = "from doc in docs\nwhere doc.ObjectType == \"Category\"\nselect new { doc.CategoryName };";
		this.IndexDefinition = (System.Collections.Generic.IEnumerable<Rhino.DivanDB.Json.JsonDynamicObject> docs) => from doc in docs
			where doc["ObjectType"] == "Category"
			select new { CategoryName = doc["CategoryName"], _id = doc["_id"].Unwrap() };
	}
}
